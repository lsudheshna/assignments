function validate()
{
var units=frm1.nou.value;
if(units==null){
alert("Electricity units are to be entered");
return false;}
var newwindow = window.open('','','width=300,height=200,left=150');
if(units>0 && units<=100)
var pr=units*2.8;
newwindow.document.write("Electricity charges are"+pr);
else if(units>100 && units<=200)
var pr=units*3.9;
newwindow.document.write("Electricity charges are"+pr);
else if(units>200)
var pr=units*4.5;
newwindow.document.write("Electricity charges are"+pr);
}
