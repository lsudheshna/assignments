import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;


public class ProductArrayList
{

	public static void main(String[] args) 
	{

		ArrayList<String> productList=new ArrayList<String>();

		String  p1=new String("REVLON");
		String  p2=new String("MAC");
		String  p3=new String("MAYBELLINE");
		String  p4=new String("LAKME");
		String  p5=new String("COLORPOPS");
		

		productList.add(p1);
		productList.add(p2);
		productList.add(p3);
		productList.add(p4);
		productList.add(p5);
		
		System.out.println("Before Sorting");
		for(String counter:productList)
		{
			System.out.println(counter);
		}
		Collections.sort(productList);
		
		System.out.println();
		System.out.println("**************");
		System.out.println("After Sorting");
		
		for(String counter:productList)
		{
			System.out.println(counter);
		}
		
	}

}
