package com.cg.mobmgm.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.mobmgm.bean.*;
import com.cg.mobmgm.exception.MobileException;
import com.cg.mobmgm.service.*;


public class MobilePurchaseClient
{
	static Scanner sc =null;
	static MobService mobSer=null;
	public static void main(String[] args) 
	{
		sc=new Scanner(System.in);
		mobSer=new MobServiceImpl();
		int choice=0;
		while(true)
		{
			System.out.println("What do u want to choose?");
			System.out.println("1.Add customer details\t"+"2.Fetch All mobiles\t"+"3.Delete mobiles\t"+"4.update mobiles\t"+"5.Search Mobiles based on price range\t"+"6.Exit");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:insertMobilePurchases();
			break;
			case 2:fetchAllMobiles();
			break;
			case 3:delmobiles();
			break;
			case 4:searchMobiles();
			break;
			default:System.exit(0);
			}
		}

	}
	/*******************main ends*********************/
	public static void insertMobilePurchases()
	{
		System.out.println("Enter Mobile Id:");
		int mid=sc.nextInt();
		try {
			if(mobSer.validateMobileId(mid))
			{
				System.out.println("Enter customername:");
				String cnm=sc.next();
				if(mobSer.validateCustName(cnm))
				{
					System.out.println("Enter customermailId:");
					String cmail=sc.next();
					if(mobSer.validatemailId(cmail))
					{
						System.out.println("Enter customerphoneNo:");
						Long cphn=sc.nextLong();
						if(mobSer.validatephnNumber(cphn))
						{
							PurchaseDetails pd=new PurchaseDetails();
							pd.setCustomerName(cnm);
							pd.setPhoneNumber(cphn);
							pd.setMailId(cmail);
							pd.setMobileId(mid);


							int dataAdded=mobSer.addMobile(pd);
							if(dataAdded==1)
							{
								System.out.println("Customer data Added:");
								//int quant=mobileDao.updateMobileQuantity(mob);
								updateMobiles(mid);
							}
							else
							{
								System.out.println("May be some Exception while Addition");
							}
						}
					}
				}
			}	
		}		

		catch (MobileException e) 
		{
			System.out.println(e.getMessage());

		}
	}
	public static void fetchAllMobiles()
	{
		try
		{
			ArrayList<Mobile> mobList=mobSer.getAllMobiles();
			for(Mobile mb:mobList)
			{
				System.out.println(mb);
			}
		}
		catch (MobileException e)
		{
			System.out.println("May be some Exception while Addition");
		}
	}
	public static void delmobiles()
	{
		System.out.println("Enter mobile Id:");
		int mid=sc.nextInt();
		
		try
		{
			if(mobSer.validateMobileId(mid))
			{
			Mobile mob=new Mobile();
			mob.setMobileId(mid);
			int delete=mobSer.deleteMobile(mid);
			if(delete==1)
			{
				System.out.println("mobile data deleted:");
			}
			}
			else
			{
				System.out.println("May be some Exception while Addition");
			}
		}
		catch (MobileException e) 
		{
			System.out.println(e.getMessage());

		}
	}
	public static void updateMobiles(int mobileId)
	{
		int updated=0;
		try
		{
			
			updated=mobSer.updateMobileQuantity(mobileId);
			if(updated>0)
			{
				System.out.println("mobile data updated:");
			}
			else
			{
				System.out.println("May be some Exception while Addition");
			}
		}
		catch (MobileException e) 
		{
			System.out.println(e.getMessage());

		}
	}
	public static void searchMobiles()
	{
		System.out.println("Enter minimum price");
		float min=sc.nextFloat();
		System.out.println("Enter maximum price");
		float max=sc.nextFloat();
		try
		{
			ArrayList<Mobile> moblList=mobSer.searchMobiles(min,max);
			for(Mobile mob:moblList)
			{
				System.out.println(mob);
			}
		}
		catch (MobileException e)
		{
			System.out.println("May be some Exception while Addition");
		}
	}
	
	
}




