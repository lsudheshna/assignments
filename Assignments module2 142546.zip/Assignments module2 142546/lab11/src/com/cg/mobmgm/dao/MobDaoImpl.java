package com.cg.mobmgm.dao;

import java.sql.*;
import java.util.*;

import com.cg.mobmgm.bean.Mobile;
import com.cg.mobmgm.bean.PurchaseDetails;
import com.cg.mobmgm.exception.MobileException;
import com.cg.mobmgm.util.DBUtil;


public class MobDaoImpl implements MobDao
{

	Connection con=null;
	Statement stmt=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	


	public MobDaoImpl()
	{
		
	}


	@Override
	public int addMobile(PurchaseDetails pd) throws MobileException
	{
		
		int dataAdded=0;
		String insertQry="insert into PurchaseDetails(purchaseid,cname,mailid,phoneno,purchasedate,mobileid) values(?,?,?,?,sysdate,?)";
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			pst.setInt(1,generatePurchaseId());
			pst.setString(2,pd.getCustomerName());
			pst.setString(3,pd.getMailId());
			pst.setLong(4,pd.getPhoneNumber());
			pst.setInt(5,pd.getMobileId());
			dataAdded=pst.executeUpdate();
		}
		catch (Exception e)
		{
			throw new MobileException(e.getMessage());

		}

		finally
		{
			try 
			{

				pst.close();
				con.close();

			}
			catch (SQLException e)
			{

				throw new MobileException(e.getMessage());
			}

		}
		return dataAdded;
	}



	@Override
	public ArrayList<Mobile> getAllMobiles() throws MobileException
	{

		ArrayList<Mobile> mobList=new ArrayList<Mobile>();
		String selectQry="SELECT * mobiles";
		Mobile mb=null;
		try 
		{
			con=DBUtil.getCon();
			stmt=con.createStatement();
			rs=stmt.executeQuery(selectQry);
			while(rs.next())
			{
				mb=new Mobile(rs.getInt("mobileid"),rs.getString("name"),rs.getFloat("price"),rs.getInt("quantity"));
				mobList.add(mb);
			}

		}
		catch (Exception e)
		{

			throw new MobileException(e.getMessage());

		} 
		finally
		{
			try
			{
				rs.close();
				stmt.close();
				con.close();
			} 
			catch (SQLException e)
			{
				throw new MobileException(e.getMessage());
			}

		}
		return mobList;
	}

	@Override
	public int generatePurchaseId() throws MobileException 
	{
		String qry="SELECT emp_seq.NEXTVAL FROM DUAL";
		int generatedVal=0;
		try 
		{
			con=DBUtil.getCon();
			stmt=con.createStatement();
			rs=stmt.executeQuery(qry);
			rs.next();
			generatedVal=rs.getInt(1);

		}
		catch (Exception e) 
		{

			throw new MobileException(e.getMessage());
		}
		finally
		{
			try
			{

				stmt.close();
				con.close();
			} 
			catch (SQLException e)
			{
				throw new MobileException(e.getMessage());
			}

		}

		return generatedVal;
	}



	@Override
	public int updateMobileQuantity(int mobileId) throws MobileException 
	{
		int updated=0;
		
		String updateQuery="update mobiles set quantity=quantity-1 where mobileid=?";
		try 
		{
			
			con=DBUtil.getCon();
			pst=con.prepareStatement(updateQuery);
			pst.setInt(1,mobileId);
			updated=pst.executeUpdate();

		}
		catch (Exception e)
		{

			throw new MobileException(e.getMessage());

		} 
		finally
		{
			try
			{

				pst.close();
				con.close();
			} 
			catch (SQLException e)
			{
				throw new MobileException(e.getMessage());
			}

		}
		return updated;



	}

	@Override
	public int deleteMobile(int mobileId) throws MobileException
	{
		int deleted=0;
		String deleteQuery="delete from mobiles where mobileid=?";
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(deleteQuery);
			pst.setInt(1,mobileId);
			deleted=pst.executeUpdate();

		}
		catch (Exception e)
		{

			throw new MobileException(e.getMessage());

		} 
		finally
		{
			try
			{

				pst.close();
				con.close();
			} 
			catch (SQLException e)
			{
				throw new MobileException(e.getMessage());
			}

		}
		return deleted;
		
	}

	@Override
	public ArrayList<Mobile> searchMobiles(float minprice,float maxprice) throws MobileException
	{
		ArrayList<Mobile> moblList=new ArrayList<Mobile>();
		String selectQry="SELECT * from mobiles where price between ? and ?";
		Mobile mob=null;
		try 
		{
			
			con=DBUtil.getCon();
			pst=con.prepareStatement(selectQry);
			pst.setFloat(1,minprice);
			pst.setFloat(2,maxprice);
			rs=pst.executeQuery();
			while(rs.next())
			{
				mob=new Mobile(rs.getInt("mobileid"),rs.getString("name"),rs.getFloat("price"),rs.getInt("quantity"));
				moblList.add(mob);
			}

		}
		catch (Exception e)
		{
			
			throw new MobileException(e.getMessage());

		} 
		finally
		{
			try
			{
				rs.close();
				pst.close();
				con.close();
			} 
			catch (SQLException e)
			{
				
				throw new MobileException(e.getMessage());
			}

		}
		return moblList;

	}

	@Override
	public ArrayList<Integer> getMobileId() throws MobileException
	{
		ArrayList<Integer> idList=new ArrayList<Integer>();
		String selectQry="SELECT mobileid from mobiles";
		Integer mob=0;
		try 
		{
			con=DBUtil.getCon();
			stmt=con.createStatement();
			rs=stmt.executeQuery(selectQry);
			while(rs.next())
			{
				//mob=new Mobile(rs.getInt("mobileid"),rs.getString("name"),rs.getFloat("price"),rs.getInt("quantity"));
				mob=new Integer(rs.getInt("mobileid"));
				idList.add(mob);
			}

		}
		catch (Exception e)
		{

			throw new MobileException(e.getMessage());

		} 
		finally
		{
			try
			{
				rs.close();
				stmt.close();
				con.close();
			} 
			catch (SQLException e)
			{
				throw new MobileException(e.getMessage());
			}

		}
		return idList;

	}

	}




