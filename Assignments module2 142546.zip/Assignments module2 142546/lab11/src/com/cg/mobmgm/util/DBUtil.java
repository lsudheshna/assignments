package com.cg.mobmgm.util;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;

import com.cg.mobmgm.exception.MobileException;



public class DBUtil 
{
	static String dbunm=null;
	static String dbpwd=null;
	static String url=null;

	public static Connection getCon()throws IOException,SQLException,MobileException
	{
		Connection con=null;
		Properties dbInfoprops=DBUtil.getProp();
		dbunm=dbInfoprops.getProperty("dbUser");
		dbpwd=dbInfoprops.getProperty("dbPwd");
		url=dbInfoprops.getProperty("dbURL");

		if(con==null)
		{
			
			con=DriverManager.getConnection(url,dbunm,dbpwd);
			
		}
		return con;
	}

	public static Properties getProp()throws IOException,MobileException
	{		
		FileReader fr=null;;
		Properties props=null;
		props=new Properties();
		fr = new FileReader("resources/mobInfo.properties");
		props.load(fr);
		return props;
	}



}


