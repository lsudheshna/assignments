package com.cg.mobmgm.service;
import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.mobmgm.bean.*;
import com.cg.mobmgm.dao.*;
import com.cg.mobmgm.exception.MobileException;


public class MobServiceImpl implements MobService
{
	MobDao mobileDao=null;
	
	public MobServiceImpl() 
	{
		super();
		mobileDao=new MobDaoImpl();
		
	}

	@Override
	public int addMobile(PurchaseDetails pd) throws MobileException
	{
		
		return mobileDao.addMobile(pd);
	}

	@Override
	public ArrayList<Mobile> getAllMobiles() throws MobileException
	{
		
		return mobileDao.getAllMobiles();
	}

	@Override
	public int generatePurchaseId() throws MobileException
	{
		
		return mobileDao.generatePurchaseId();
	}

	@Override
	public int updateMobileQuantity(int mobileId) throws MobileException
	{
		
		return mobileDao.updateMobileQuantity(mobileId);
	}

	@Override
	public int deleteMobile(int mobileId) throws MobileException 
	{
		
		return mobileDao.deleteMobile(mobileId);
	}

	@Override
	public ArrayList<Mobile> searchMobiles(float minprice,float maxprice)
			throws MobileException 
			{
		
		return mobileDao.searchMobiles(minprice,maxprice);
	}

	@Override
	public ArrayList<Integer> getMobileId() throws MobileException
	{
		
		return mobileDao.getMobileId();
	}
	
	/*@Override
	public int getMobileQuantity(Mobile mob) throws MobileException
	{
		
		return mobileDao.getMobileQuantity();
	}*/
	
	@Override
	public boolean validateMobileId(int mobileId) throws MobileException
	{
		String numPattern="[0-9]{4}";
		int flag=0;
		if(Pattern.matches(numPattern, new Integer(mobileId).toString()))
		{
			/*ArrayList<Integer> mobList=mobileDao.getMobileId();
			for(int temp:mobList)
			{
				if(mobileId==temp)
				{
					flag=1;
				}
			}
		}
		if(flag==1)
		{*/
			return true;
		}
		else
		{
			throw new MobileException("Only Min 4 digits are passed");
		}
	}

	@Override
	public boolean validateCustName(String customerName) throws MobileException
	{
		String namePattern="[A-z][a-zA-Z]{3,20}";
		if(Pattern.matches(namePattern,customerName))
		{
			return true;
		}
		else
		{
			throw new MobileException("Min 3 and Max 20 digits are allowed");
		}
	}

	@Override
	public boolean validatemailId(String mailId) throws MobileException
	{
		String mailPattern="[a-zA-z0-9]{5,}[@][a-z]{4,5}+[.][a-z]{2,3}";
		if(Pattern.matches(mailPattern,mailId))
		{
			return true;
		}
		else
		{
			throw new MobileException("Enter valid emailId");
		}
		
	}

	@Override
	public boolean validatephnNumber(long phoneNumber) throws MobileException
	{
		String numPattern="[987]{1}[0-9]{9}";
		if(Pattern.matches(numPattern, new Long(phoneNumber).toString()))
		{
			return true;
		}
		else
		{
			throw new MobileException("Only 10 digits are allowed");
		}
	}

	
	/*public boolean validateQuantity(PurchaseDetails pd) throws MobileException
	{
		int quantList=mobileDao.getMobileQuantity();
		if(quantList>0)
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}*/

	
	
}
