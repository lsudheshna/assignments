
public class PersonTestDemo {

	public static void main(String[] args) 
	{
		Person p1=new Person("Divya","Bharathi",'F',20,85.55);
		System.out.println(p1.dispPersonInfo());

	}

}
