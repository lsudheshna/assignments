
public class Person1
{
	private String firstName;
	private String lastName;
	private char gender;
	private long phoneNo;
	
	public Person1()
	{
		firstName=null;
		lastName=null;
		gender= ' ';
		
	}

	public void setPerson1(String firstName,String lastName,char gender,long phoneNo)
	{
		this.firstName=firstName;
		this.lastName=lastName;
		this.gender=gender;
		this.phoneNo=phoneNo;
	}
	
	public String dispPersonDetails()
	{
		
		return "First Name:"+firstName+"\n"+"Last Name:"+lastName+"\n"+"Gender:"+gender+"\n"+"PhoneNo:"+phoneNo;
	}
	
}
