
public class PersonMain 
{

	public static void main(String[] args)
	{
			Person p1=new Person();
			Person p2=new Person();
			p1.setPerson("sudheshna","channa",'F');
			p2.setPerson("Apoorva","Shetty",'F');
			
			
			System.out.println("Person Details");
			System.out.println("----------------------");
			System.out.println("First Name:"+p1.getFirstName());
			System.out.println("Last Name:"+p1.getLastName());
			System.out.println("Gender:"+p1.getGender());

			System.out.println("Person Details");
			System.out.println("----------------------");
			System.out.println("First Name:"+p2.getFirstName());
			System.out.println("Last Name:"+p2.getLastName());
			System.out.println("Gender:"+p2.getGender());
	}

}
