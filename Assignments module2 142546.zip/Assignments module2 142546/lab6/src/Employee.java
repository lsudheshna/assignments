import java.util.Scanner;


public class Employee 
{
	public static void main(String args[])
	{
		Scanner s=new Scanner(System.in);
		Person p1=new Person();
		
		System.out.println("Enter employee first name:");
		String fname=s.next();
		
		System.out.println("Enter employee last name:");
		String lname=s.next();
		
		if((fname.equals("null")) || (lname.equals("null"))||(fname.equals("_")) || (lname.equals("_")))
		{
			try
			{
			throw new EmployeeException("firstname and lastname should be entered");
			}
			catch(EmployeeException e)
			{
				System.out.println("firstname and lastname are blank");
				e.printStackTrace();
			}
			
		}
		else
		{
			p1.setPerson(fname,lname);
			System.out.println(p1.dispPersonDetails());
		}
	}
}
