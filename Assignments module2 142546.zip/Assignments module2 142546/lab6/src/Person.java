
public class Person 
{
	private String firstName;
	private String lastName;
	
	
	public Person()
	{
		firstName=null;
		lastName=null;
		
	}

	public void setPerson(String firstName,String lastName)
	{
		this.firstName=firstName;
		this.lastName=lastName;
		
	}
	
	public String dispPersonDetails()
	{
		
		return "First Name:"+firstName+"\n"+"Last Name:"+lastName+"";
	}
}
