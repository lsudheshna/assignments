package com.cg.eis.pl;
import java.util.Scanner;
import com.cg.eis.*;
import com.cg.eis.bean.Employee;
import com.cg.eis.service.Service;

public class TestEmployeeServices
{
	
	public static void main(String[] args) 
	
	{	int i;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter no of Employees:");
		int n=s.nextInt();
		Employee emps[]=new Employee[n];
		Service ss=new Service();
	for(i=0;i<emps.length;i++)
	{
		System.out.println("Enter employee ID:");
		int eId=s.nextInt();
		System.out.println("Enter employee Name:");
		String eName=s.next();
		System.out.println("Enter employee Salary:");
		float eSal=s.nextFloat();
		System.out.println("Enter employee designation:");
		String edes=s.next();
		emps[i]=new Employee(eId,eName,eSal,edes,ss);
		System.out.println("Employee details"+emps[i].dispEmployeeInfo());
	
		
	}
	}

}
