package com.cg.eis.service;

public interface EmployeeService
{
	public String dispService(float eSal,String edes);
}
