package com.cg.ctrl;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.Bill;
import com.cg.dto.Consumer;
import com.cg.service.*;


@WebServlet("/LoginController")
public class LoginController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	eBillService eSer=null;
	Bill bill=null;
	
	public LoginController() {
		super();

	}


	public void init(ServletConfig config) throws ServletException
	{

	}


	public void destroy()
	{

	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		doPost(request,response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
	{
		HttpSession session=request.getSession(true);
		eSer = new eBillServiceImpl();
		String action=request.getParameter("action");
		RequestDispatcher rd=null;
		bill=new Bill();
		int dataadded=0;
		PrintWriter out=response.getWriter();
		
		if(action!=null)
		{
			try
			{
				if(action.equals("ShowWelcomePage"))
				{
					rd=request.getRequestDispatcher("Welcome.jsp");
					rd.forward(request, response);
				}
				if(action.equals("ShowLoginPage"))
				{

					rd=request.getRequestDispatcher("Login.jsp");
					rd.forward(request, response);
				}
				if(action.equals("eBillCalcPage"))
				{
					
					String unm=request.getParameter("txtname");
					String pwd=request.getParameter("pwdname");

					
					if ( (unm.equals("admin")) && (pwd.equals("admin")) )
					{
						//session.setAttribute("userNameObj", unm);
						rd=request.getRequestDispatcher("eBill.jsp");
						rd.forward(request, response);
					}
					else
					{
						String msg="Sorry .Please check your Password.";
						request.setAttribute("ErrorMsgObj", msg);
						rd=request.getRequestDispatcher("Login.jsp");
						rd.forward(request, response);
					}
				}
				
				if(action.equals("ShowSuccessPage"))
				{
					String id=request.getParameter("id");
					String lst=request.getParameter("last");
					String curr=request.getParameter("current");

					long idnum=Long.parseLong(id);
					float lastr=Float.parseFloat(lst);
					float currReading=Float.parseFloat(curr);
					
					float unitsConsumed=lastr-currReading;
					float fixedCharge=100;
					float netAmount=unitsConsumed*1.15f+fixedCharge;
					
					bill.setConsumernum(idnum);
					bill.setUnits(unitsConsumed);
					bill.setBillamt(netAmount);
					bill.setCurreading(currReading);
					dataadded=eSer.BillCalc(bill);
					if(dataadded==1)
					{
					session.setAttribute("numObj", idnum);
					session.setAttribute("unitsObj",unitsConsumed);
					session.setAttribute("totalObj",netAmount);
					rd=request.getRequestDispatcher("/SuccessPage");
					rd.forward(request, response);
					}
					else
					{
						out.println("Insertion fail");
					}
				}
			}
			catch(Exception e)
			{
				String errMsg=e.getMessage();
				request.setAttribute("ErrorMsgObj", errMsg);
				RequestDispatcher rdError=request.getRequestDispatcher("ShowErrorPage");
				rdError.forward(request, response);
			}
		}
		else
		{
			response.getWriter().println("No Action is required");
		}
	}
}