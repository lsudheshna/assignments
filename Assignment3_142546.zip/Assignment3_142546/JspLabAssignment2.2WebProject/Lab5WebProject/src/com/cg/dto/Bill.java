package com.cg.dto;

import java.sql.Date;

public class Bill
{
	private long billnum;
	private long consumernum;
	private float curreading;
	private float units;
	private float billamt;
	
	
	public Bill() 
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public Bill(long billnum, long consumernum, float curreading,
		 float units, float billamt) 
	{
		super();
		this.billnum = billnum;
		this.consumernum = consumernum;
		this.curreading = curreading;
		
		this.units = units;
		this.billamt = billamt;
		
	}

	public long getBillnum() {
		return billnum;
	}

	public void setBillnum(long billnum) {
		this.billnum = billnum;
	}

	public long getConsumernum() {
		return consumernum;
	}

	public void setConsumernum(long consumernum) {
		this.consumernum = consumernum;
	}

	public float getCurreading() {
		return curreading;
	}

	public void setCurreading(float curreading) {
		this.curreading = curreading;
	}

	public float getUnits() {
		return units;
	}

	public void setUnits(float units) {
		this.units = units;
	}

	public float getBillamt() {
		return billamt;
	}

	public void setBillamt(float billamt) {
		this.billamt = billamt;
	}


	@Override
	public String toString() {
		return "Bill [billnum=" + billnum + ", consumernum=" + consumernum
				+ ", curreading=" + curreading 
				+ ", units=" + units + ", billamt=" + billamt +"]";
	}
	
	
	
}
