package com.cg.dao;

import java.sql.*;
import java.util.*;

import com.cg.dto.Bill;
import com.cg.dto.Consumer;
import com.cg.exception.BillException;
import com.cg.util.DBUtil;

public class eBillDaoImpl implements eBillDao

{
	Connection con=null;
	PreparedStatement pst=null;
	Statement stmt=null;
	ResultSet rs=null;
	
	@Override
	public String getCustomerName(long consumernum) throws BillException
	{
		String selectQry="SELECT  consumer_name from Consumers where consumer_num=?";
		Consumer cm=null;
		String name=null;
			try
			{
			con=DBUtil.getCon();
			pst=con.prepareStatement(selectQry);
			pst.setLong(1, consumernum);
			rs=pst.executeQuery();
			rs.next();
			name=rs.getString(1);
			System.out.println(name);
			}
			catch(Exception e)
			{
				throw new BillException(e.getMessage());
			}
			return name;

	}

	@Override
	public int BillCalc(Bill b) throws BillException 
	{
		int dataadded=0;
		try
		{
		con=DBUtil.getCon();
		Consumer c=new Consumer();
		System.out.println("Got Connection");
		String qry="insert into BillDetails(bill_num,consumer_num,cur_reading,unitConsumed,netAmount)values(?,?,?,?,? )";
		pst=con.prepareStatement(qry);
		pst.setLong(1,generatebillnum());
		pst.setLong(2,b.getConsumernum());
		pst.setFloat(3, b.getCurreading());
		pst.setFloat(4, b.getUnits());
		pst.setFloat(5, b.getBillamt());

		dataadded=pst.executeUpdate();
		}
		catch(Exception e)
		{
			throw new BillException(e.getMessage());
		}
		return dataadded;
	}
	
	public int generatebillnum() throws BillException 
	{
		String qry="SELECT seq_bill_num.NEXTVAL FROM DUAL";
		int generatedVal=0;
		
			try
			{
			con=DBUtil.getCon();
			stmt=con.createStatement();
			rs=stmt.executeQuery(qry);
			rs.next();
			generatedVal=rs.getInt(1);
			}
			catch(Exception e)
			{
				throw new BillException(e.getMessage());
			}
			return generatedVal;
	}
		
}
