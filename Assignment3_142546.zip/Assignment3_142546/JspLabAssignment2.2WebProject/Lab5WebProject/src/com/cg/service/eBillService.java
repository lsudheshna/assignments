package com.cg.service;

import java.util.ArrayList;

import com.cg.dto.Bill;
import com.cg.dto.Consumer;
import com.cg.exception.BillException;

public interface eBillService
{
public String getCustomerName(long consumernum) throws BillException;
	
	public int BillCalc(Bill b)throws BillException;
	
	public int generatebillnum() throws BillException;
}
