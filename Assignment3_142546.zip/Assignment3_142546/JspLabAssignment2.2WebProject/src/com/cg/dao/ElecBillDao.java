package com.cg.dao;

import java.util.ArrayList;

import com.cg.dto.Consumer;
import com.cg.dto.ElectricityBill;
import com.cg.exception.BillException;
import com.cg.exception.ConsumerException;

public interface ElecBillDao
{
	public int addBillDetails(ElectricityBill elecBill) throws Exception,BillException;
	public long generateBillNumber() throws Exception,BillException;
	public ArrayList<Integer> getConsumerNo() throws Exception,BillException;
	public String getConsumerName(int consumerNumber) throws Exception,BillException;
	public ArrayList<Consumer> getAllConsumerDetails() throws ConsumerException;
	public Consumer getConsumerById(long consumerNumber) throws ConsumerException;
	public ArrayList<ElectricityBill> showBillDetails(long consumerNo) throws BillException; 
}
