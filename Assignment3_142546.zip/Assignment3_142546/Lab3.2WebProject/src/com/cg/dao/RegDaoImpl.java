package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.dto.Registration;
import com.cg.util.DBUtil;

public class RegDaoImpl implements RegDao
{
	Connection con=null;
	PreparedStatement pst=null;
	Registration user=null;
	
	@Override
	public int getUser(Registration reg) throws SQLException
	{
		con=DBUtil.getCon();
		System.out.println("Got Connection");
		String qry="insert into RegisteredUsers(firstname,lastname,password,gender,skillset,city)values(?,?,?,?,?,? )";
		pst=con.prepareStatement(qry);
		pst.setString(1, reg.getFname());
		pst.setString(2, reg.getLname());
		pst.setString(3, reg.getPassword());
		pst.setString(4, reg.getGender());
		pst.setString(5, reg.getSkill());
		pst.setString(6, reg.getCity());
		int dataadded=pst.executeUpdate();
		return dataadded;
	}
}
