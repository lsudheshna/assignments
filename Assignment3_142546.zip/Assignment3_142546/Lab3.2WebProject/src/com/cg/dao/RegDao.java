package com.cg.dao;

import java.sql.SQLException;

import com.cg.dto.Registration;

public interface RegDao
{
	public int getUser(Registration reg) throws SQLException;
}
