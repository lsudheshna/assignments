package com.cg.dto;

public class Registration 
{
	private String fname;
	private String lname;
	private String password;
	private String gender;
	private String skill;
	private String city;
	
	public Registration() 
	{
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Registration(String fname, String lname, String password,
			String gender, String skill, String city) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.password = password;
		this.gender = gender;
		this.skill = skill;
		this.city = city;
	}


	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getSkill() {
		return skill;
	}

	public void setSkill(String skill) {
		this.skill = skill;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "Registration [fname=" + fname + ", lname=" + lname
				+ ", password=" + password + ", gender=" + gender + ", skill="
				+ skill + ", city=" + city + "]";
	}
	
	
	
}
