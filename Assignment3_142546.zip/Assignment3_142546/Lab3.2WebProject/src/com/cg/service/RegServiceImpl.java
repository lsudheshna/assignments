package com.cg.service;

import java.sql.SQLException;

import com.cg.dao.RegDao;
import com.cg.dao.RegDaoImpl;
import com.cg.dto.Registration;

public class RegServiceImpl
{
	RegDao reDao=null;
	
	
	public RegServiceImpl() {
		super();
		reDao=new RegDaoImpl();
	}


	public int getUser(Registration reg) throws SQLException
	{
		
		return reDao.getUser(reg);
	}
}
