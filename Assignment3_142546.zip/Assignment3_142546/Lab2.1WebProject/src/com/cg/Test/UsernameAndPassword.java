package com.cg.Test;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.regex.Pattern;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "UsernameAndPasswordName", urlPatterns = { "/UsernameAndPasswordMap" })
public class UsernameAndPassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public UsernameAndPassword() 
    {
        super();
      
    }

	public void init(ServletConfig config) throws ServletException
	{
		
	}

	public void destroy() 
	{
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doPost(request,response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter pw=response.getWriter();
		String unm=request.getParameter("txtname");
		String pwd=request.getParameter("pwdname");
		
		if ((Pattern.matches(unm, "sudheshna")) && (Pattern.matches(pwd, "sudha")))
		{
			response.sendRedirect("/Lab2.1WebProject/success.html");
		}
		else
		{
			response.sendRedirect("/Lab2.1WebProject/failure.html");
		}
		
	}

}
