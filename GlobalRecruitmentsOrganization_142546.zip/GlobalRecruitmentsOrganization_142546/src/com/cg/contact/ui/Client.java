package com.cg.contact.ui;

import java.util.ArrayList;
import java.util.Scanner;
import com.cg.contact.bean.EnquiryBean;
import com.cg.contact.exception.ContactBookException;
import com.cg.contact.service.ContactBookService;
import com.cg.contact.service.ContactBookServiceImpl;



public class Client
{
	static Scanner sc =null;
	static ContactBookService cSer=null;
	public static void main(String[] args)
	{
		sc=new Scanner(System.in);
		cSer=new ContactBookServiceImpl();
		int choice=0;
		while(true)
		{
			System.out.println("************Global Recruitments*************");
			System.out.println("Choose an operation");
			System.out.println("1.Add Enquiry details\n"+"2.Fetch All enquiries\n"+"0.Exit");
			System.out.println("************");
			System.out.print("Please enter a choice:");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:addEnquiryDetails();
			break;
			case 2:searchEnquiryDetails1();
			break;
			case 0:
				System.out.println("Thankyou selecting us!!");
				System.exit(0);
				
			}
		}
	}
	public static void addEnquiryDetails()
	{
		try 
		{
			System.out.println("Enter First Name:");
			String fnm=sc.next();
			if(cSer.validateFirstName(fnm))
			{
				System.out.println("Enter Last name:");
				String lnm=sc.next();
				if(cSer.validateLastname(lnm))
				{
					System.out.println("Enter Contact Number:");
					String phn=sc.next();
					if(cSer.validateContactNo(phn))
					{
						System.out.println("Enter Preferred Domain:");
						String domain=sc.next(); 

						if(cSer.validatePDomain(domain))
						{
							System.out.println("Enter Preferred Location:");
							String loc=sc.next();
							if(cSer.validatePLocation(loc))
							{	
								EnquiryBean enqry=new EnquiryBean();
								enqry.setContactNo(phn);
								enqry.setfName(fnm);
								enqry.setLname(lnm);
								enqry.setpDomain(domain);
								enqry.setpLocation(loc);


								int dataAdded=cSer.addEnquiry(enqry);
								if(dataAdded==1)
								{
									System.out.println("Customer data Added:");
								}
								else
								{
									System.out.println("May be some Exception while Addition");
								}
							}
						}
					}
				}	
			}
		}
		catch (ContactBookException e) 
			{
					System.out.println(e.getMessage());

			}
	}
	public static void searchEnquiryDetails1()
	{
		System.out.println("Enter Enquiry Id:");
		int eid1=sc.nextInt(); 
		try
		{
			ArrayList<EnquiryBean> enqryList=cSer.getEnquiryDetails1(eid1);
			for(EnquiryBean eb:enqryList)
			{
				System.out.println(eb);
			}
		}
		catch (ContactBookException e)
		{
			System.out.println("May be some Exception while Addition");
			System.out.println("Sorry no details found!!");
		}
	}
	
	
	
}
		
	


