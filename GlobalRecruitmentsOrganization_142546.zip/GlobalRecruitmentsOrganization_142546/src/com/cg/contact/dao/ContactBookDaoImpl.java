package com.cg.contact.dao;


import java.sql.*;
import java.util.*;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.cg.contact.bean.EnquiryBean;
import com.cg.contact.exception.ContactBookException;
import com.cg.contact.util.contactUtil;


public class ContactBookDaoImpl implements ContactBookDao
{
	Connection con=null;
	Statement statement=null;
	PreparedStatement preparedStatement=null;
	ResultSet rs=null;
	Logger cLogger=null;

	public ContactBookDaoImpl() 
	{
		super();
		PropertyConfigurator.configure("resources/log4j.properties");
		cLogger=Logger.getLogger("ContactBookDaoImpl.class");

	}

	/***********AUTHOR NAME:CHANNA LAXMI SUDHESHNA
				MODIFIED DATE:25-1-2018
				DESCRIPTION:INSERTING ENQUIRY DETAILS OF USER**************/
	
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException
	{
		String insertQry="INSERT INTO enquiry(enqryId,firstName,lastName,contactNo,domain,city) VALUES(?,?,?,?,?,?)";
		int dataAdded=0;
		try
		{
			cLogger.info("THIS IS INSERTING ENQUIRY DETAILS");

			con=contactUtil.getCon();
			preparedStatement=con.prepareStatement(insertQry);
			preparedStatement.setInt(1,generateEnquiryId());
			preparedStatement.setString(2,enqry.getfName());
			preparedStatement.setString(3,enqry.getLname());
			preparedStatement.setString(4,enqry.getContactNo());
			preparedStatement.setString(5,enqry.getpLocation());
			preparedStatement.setString(6,enqry.getpDomain());
			dataAdded=preparedStatement.executeUpdate();

		}
		catch (Exception e) 
		{	
			cLogger.error("This is Exception:"+e.getMessage());
			throw new ContactBookException(e.getMessage());
		} 
		finally
		{
			try 
			{

				preparedStatement.close();
				con.close();

			}
			catch (SQLException e)
			{
				cLogger.error("This is Exception:"+e.getMessage());
				throw new ContactBookException(e.getMessage());
			}

		}
		return dataAdded;

	}
	/***********AUTHOR NAME:CHANNA LAXMI SUDHESHNA
				MODIFIED DATE:25-1-2018
				DESCRIPTION:GENERATING ENQUIRYID USING SEQUENCE**************/
	@Override
	public int generateEnquiryId() throws ContactBookException 
	{
		String qry="SELECT enquiries.NEXTVAL FROM DUAL";
		int generatedVal=0;
		try 
		{
			cLogger.info("THIS IS GENERATING ENQUIRY ID USING SEQUENCE ");
			con=contactUtil.getCon();
			statement=con.createStatement();
			rs=statement.executeQuery(qry);
			rs.next();
			generatedVal=rs.getInt(1);

		}
		catch (Exception e) 
		{
			cLogger.error("This is Exception:"+e.getMessage());
			throw new ContactBookException(e.getMessage());
		}
		finally
		{
			try
			{

				statement.close();
				con.close();
			} 
			catch (SQLException e)
			{
				cLogger.error("This is Exception:"+e.getMessage());
				throw new ContactBookException(e.getMessage());
			}

		}

		return generatedVal;
	}
	/***********AUTHOR NAME:CHANNA LAXMI SUDHESHNA
				MODIFIED DATE:25-1-2018
				DESCRIPTION:FETCHING ENQUIRY DETAILS OF USER USING ENQUIRYID**************/
	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID)throws ContactBookException 
	{
		ArrayList<EnquiryBean> enqryList=new ArrayList<EnquiryBean>();
		String selectQry="SELECT * from mobiles";
		EnquiryBean eBean=null;
		try 
		{
			cLogger.info("THIS IS FETCHING ENQUIRY DETAILS");
			con=contactUtil.getCon();
			statement=con.createStatement();
			rs=statement.executeQuery(selectQry);
			while(rs.next())
			{
				eBean=new EnquiryBean(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6));
				enqryList.add(eBean);
			}

		}
		catch (Exception e)
		{
			cLogger.error("This is Exception:"+e.getMessage());
			throw new ContactBookException(e.getMessage());

		} 
		finally
		{
			try
			{
				rs.close();
				statement.close();
				con.close();
			} 
			catch (SQLException e)
			{
				cLogger.error("This is Exception:"+e.getMessage());
				throw new ContactBookException(e.getMessage());
			}

		}
		return eBean;

	}
	/***********AUTHOR NAME:CHANNA LAXMI SUDHESHNA
				MODIFIED DATE:25-1-2018
				DESCRIPTION:FETCHING ENQUIRY DETAILS OF USER USING ENQUIRYID**************/
	@Override
	public ArrayList<EnquiryBean> getEnquiryDetails1(int EnquiryID)throws ContactBookException 
	{
		ArrayList<EnquiryBean> enqryList=new ArrayList<EnquiryBean>();
		String selectQry="SELECT * from enquiry where enqryId=?";
		EnquiryBean eBean=null;
		try 
		{
			cLogger.info("THIS IS FETCHING ENQUIRY DETAILS");
			con=contactUtil.getCon();
			preparedStatement=con.prepareStatement(selectQry);
			preparedStatement.setInt(1,EnquiryID);
			rs=preparedStatement.executeQuery();
			while(rs.next())
			{
				eBean=new EnquiryBean(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6));
				enqryList.add(eBean);
			}

		}
		catch (Exception e)
		{
			cLogger.error("This is Exception:"+e.getMessage());
			throw new ContactBookException(e.getMessage());

		} 
		finally
		{
			try
			{
				rs.close();
				preparedStatement.close();
				con.close();
			} 
			catch (SQLException e)
			{
				cLogger.error("This is Exception:"+e.getMessage());
				throw new ContactBookException(e.getMessage());
			}

		}
		return enqryList;

	}
}
