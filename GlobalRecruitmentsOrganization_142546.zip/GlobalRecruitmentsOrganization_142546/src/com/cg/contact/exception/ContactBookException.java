package com.cg.contact.exception;

public class ContactBookException extends Exception
{
	public ContactBookException(String msg)
	{
		super(msg);
	}
}
