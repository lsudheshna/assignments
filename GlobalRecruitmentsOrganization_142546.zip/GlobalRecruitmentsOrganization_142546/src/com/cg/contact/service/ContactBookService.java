package com.cg.contact.service;

import java.util.ArrayList;
import com.cg.contact.bean.EnquiryBean;
import com.cg.contact.exception.ContactBookException;

//USING INTERFACE FOR INSERING DETAILS,GENERATING ENQUIRYID,FETCHING DETAILS AND FOR VALIDATION

public interface ContactBookService
{
	public int addEnquiry(EnquiryBean enqry)throws ContactBookException;

	public EnquiryBean getEnquiryDetails(int EnquiryID)throws ContactBookException;

	int generateEnquiryId() throws ContactBookException;

	ArrayList<EnquiryBean> getEnquiryDetails1(int EnquiryID)
			throws ContactBookException;

	public boolean isValidEnquiry(EnquiryBean enqry)throws ContactBookException;

	public boolean validateContactNo(String contactNo)throws ContactBookException;

	public boolean validateFirstName(String fName)throws ContactBookException;

	public boolean validateLastname(String lName)throws ContactBookException;

	public boolean validatePLocation(String pLocation)throws ContactBookException;

	public boolean validatePDomain(String pDomain)throws ContactBookException;
}
