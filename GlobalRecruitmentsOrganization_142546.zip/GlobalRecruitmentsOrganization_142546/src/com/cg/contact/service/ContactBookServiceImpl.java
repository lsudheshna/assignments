package com.cg.contact.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.contact.bean.EnquiryBean;
import com.cg.contact.dao.*;
import com.cg.contact.exception.ContactBookException;

public class ContactBookServiceImpl implements ContactBookService
{
	ContactBookDaoImpl contactDao=null;

	public ContactBookServiceImpl()
	{
		super();
		contactDao=new ContactBookDaoImpl();
	}

	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException
	{
		return contactDao.addEnquiry(enqry);
		
	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID)throws ContactBookException 
	{
		
		return contactDao.getEnquiryDetails(EnquiryID);
	}

	@Override
	public int generateEnquiryId() throws ContactBookException
	{
		
		return contactDao.generateEnquiryId();
	}

	@Override
	public ArrayList<EnquiryBean> getEnquiryDetails1(int EnquiryID)throws ContactBookException
			{
		
		return contactDao.getEnquiryDetails1(EnquiryID);
	}
	
	@Override
	public boolean isValidEnquiry(EnquiryBean enqry) throws ContactBookException
	{
		
		validateContactNo(enqry.getContactNo());
		validateFirstName(enqry.getfName());
		validateLastname(enqry.getLname());
		validatePLocation(enqry.getpLocation());
		validatePDomain(enqry.getpDomain());
		
		return true;
	}
	/***********AUTHOR NAME:CHANNA LAXMI SUDHESHNA
				MODIFIED DATE:25-1-2018
				DESCRIPTION:VALIDATING PHONENUMBER**************/
	@Override
	public boolean validateContactNo(String contactNo) throws ContactBookException 
	{
		String numPattern="[987]{1}[0-9]{9}";
		if(Pattern.matches(numPattern,contactNo))
		{
			return true;
		}
		else
		{
			throw new ContactBookException("Only 10 digits are allowed");
		}
	
	}
	/***********AUTHOR NAME:CHANNA LAXMI SUDHESHNA
				MODIFIED DATE:25-1-2018
				DESCRIPTION:VALIDATING FIRSTNAME**************/
	@Override
	public boolean validateFirstName(String fName) throws ContactBookException
	{
		String namePattern="[A-z][a-zA-Z]{3,20}";
		if(Pattern.matches(namePattern,fName))
		{
			return true;
		}
		else
		{
			throw new ContactBookException("Minimum 3 and Maximum 20 characters are allowed e.g.Sudheshna");
		}
	}
	/***********AUTHOR NAME:CHANNA LAXMI SUDHESHNA
				MODIFIED DATE:25-1-2018
				DESCRIPTION:LAST NAME**************/
	@Override
	public boolean validateLastname(String lName) throws ContactBookException 
	{
		String namePattern="[A-z][a-zA-Z]{3,6}";
		if(Pattern.matches(namePattern,lName))
		{
			return true;
		}
		else
		{
			throw new ContactBookException("Minimum 3 and Max 6 characters are allowed e.g.Shetty");
		}
	}

	@Override
	public boolean validatePLocation(String pLocation)throws ContactBookException 
	{
		String namePattern="[a-zA-Z]{3,8}";
		if(Pattern.matches(namePattern,pLocation))
		{
			return true;
		}
		else
		{
			throw new ContactBookException("Minimum 3 and Maximum 8 characters are allowed");
		}
	}

	@Override
	public boolean validatePDomain(String pDomain) throws ContactBookException 
	{
		String namePattern="[a-zA-Z]{3,6}";
		if(Pattern.matches(namePattern,pDomain))
		{
			return true;
		}
		else
		{
			throw new ContactBookException("Minimum 3 and Maximum 6 characters are allowed");
		}
	}

}
